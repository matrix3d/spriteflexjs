<!--

    Licensed to the Apache Software Foundation (ASF) under one
    or more contributor license agreements.  See the NOTICE file
    distributed with this work for additional information
    regarding copyright ownership.  The ASF licenses this file
    to you under the Apache License, Version 2.0 (the
    "License"); you may not use this file except in compliance
    with the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing,
    software distributed under the License is distributed on an
    "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, either express or implied.  See the License for the
    specific language governing permissions and limitations
    under the License.

-->

#### Contributors

 * Andrew Dufilie (https://github.com/adufilie)
 * Alex Harui (https://github.com/aharui)
 * Alina Kazi (https://github.com/alinakazi)
 * Omprakash Muppirala (https://github.com/bigosmallm)
 * Carlos Rovira (https://github.com/carlosrovira)
 * Christofer Dutz (https://github.com/chrisdutz)
 * Andrew Wetmore (https://github.com/cottage14)
 * Cristallium (https://github.com/cristallium)
 * Frédéric Thomas (https://github.com/doublefx)
 * doug777 (https://github.com/doug777)
 * Erik DeBruin (https://github.com/erikdebruin)
 * Greg Dove (https://github.com/greg-dove)
 * Harbs (https://github.com/harbs)
 * Jimmy Casey (https://github.com/jimmycasey)
 * Josh Tynjala (https://github.com/joshtynjala)
 * Justin Mclean (https://github.com/justinmclean)
 * Kevin Godell (https://github.com/kevinGodell)
 * LHR07-DBz (https://github.com/LHR07-DBz)
 * lizhi (https://github.com/matrix3d)
 * MujtabaMughal (https://github.com/MujtabaMughal)
 * Olaf Krueger (https://github.com/olafkrueger)
 * Pashmina Kazi (https://github.com/pashminakazi)
 * Peter Ent (https://github.com/pentapache)
 * Piotr Zarzycki (https://github.com/piotrzarzycki21)
 * SAdelman (https://github.com/SAdelman)
 * Shoichiro Takeshita (https://github.com/T-San001)
 * yestaro (https://github.com/yestaro)
 * Yishay Weiss (https://github.com/yishayw)
 
